﻿namespace hegyek_menupontok_leitli
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.feladatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feladatToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.feladatSzámolásToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feladatÁtlagToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feladatLegmagasabbToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feladatBörzsönyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feladat3000LábToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feladatStatisztikaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feladatBukkvidektxtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kilépésToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.feladatToolStripMenuItem,
            this.kilépésToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // feladatToolStripMenuItem
            // 
            this.feladatToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.feladatToolStripMenuItem1,
            this.feladatSzámolásToolStripMenuItem,
            this.feladatÁtlagToolStripMenuItem,
            this.feladatLegmagasabbToolStripMenuItem,
            this.feladatBörzsönyToolStripMenuItem,
            this.feladat3000LábToolStripMenuItem,
            this.feladatStatisztikaToolStripMenuItem,
            this.feladatBukkvidektxtToolStripMenuItem});
            this.feladatToolStripMenuItem.Name = "feladatToolStripMenuItem";
            this.feladatToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.feladatToolStripMenuItem.Text = "Feladatok";
            // 
            // feladatToolStripMenuItem1
            // 
            this.feladatToolStripMenuItem1.Name = "feladatToolStripMenuItem1";
            this.feladatToolStripMenuItem1.Size = new System.Drawing.Size(209, 22);
            this.feladatToolStripMenuItem1.Text = "2. feladat - Beolvasás";
            this.feladatToolStripMenuItem1.Click += new System.EventHandler(this.feladatToolStripMenuItem1_Click);
            // 
            // feladatSzámolásToolStripMenuItem
            // 
            this.feladatSzámolásToolStripMenuItem.Name = "feladatSzámolásToolStripMenuItem";
            this.feladatSzámolásToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.feladatSzámolásToolStripMenuItem.Text = "3. feladat - Számolás";
            this.feladatSzámolásToolStripMenuItem.Click += new System.EventHandler(this.feladatSzámolásToolStripMenuItem_Click);
            // 
            // feladatÁtlagToolStripMenuItem
            // 
            this.feladatÁtlagToolStripMenuItem.Name = "feladatÁtlagToolStripMenuItem";
            this.feladatÁtlagToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.feladatÁtlagToolStripMenuItem.Text = "4. feladat - Átlag";
            this.feladatÁtlagToolStripMenuItem.Click += new System.EventHandler(this.feladatÁtlagToolStripMenuItem_Click);
            // 
            // feladatLegmagasabbToolStripMenuItem
            // 
            this.feladatLegmagasabbToolStripMenuItem.Name = "feladatLegmagasabbToolStripMenuItem";
            this.feladatLegmagasabbToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.feladatLegmagasabbToolStripMenuItem.Text = "5. feladat - Legmagasabb";
            this.feladatLegmagasabbToolStripMenuItem.Click += new System.EventHandler(this.feladatLegmagasabbToolStripMenuItem_Click);
            // 
            // feladatBörzsönyToolStripMenuItem
            // 
            this.feladatBörzsönyToolStripMenuItem.Name = "feladatBörzsönyToolStripMenuItem";
            this.feladatBörzsönyToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.feladatBörzsönyToolStripMenuItem.Text = "6. feladat - Börzsöny";
            this.feladatBörzsönyToolStripMenuItem.Click += new System.EventHandler(this.feladatBörzsönyToolStripMenuItem_Click);
            // 
            // feladat3000LábToolStripMenuItem
            // 
            this.feladat3000LábToolStripMenuItem.Name = "feladat3000LábToolStripMenuItem";
            this.feladat3000LábToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.feladat3000LábToolStripMenuItem.Text = "7. feladat - 3000 láb";
            this.feladat3000LábToolStripMenuItem.Click += new System.EventHandler(this.feladat3000LábToolStripMenuItem_Click);
            // 
            // feladatStatisztikaToolStripMenuItem
            // 
            this.feladatStatisztikaToolStripMenuItem.Name = "feladatStatisztikaToolStripMenuItem";
            this.feladatStatisztikaToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.feladatStatisztikaToolStripMenuItem.Text = "8. feladat - Statisztika";
            this.feladatStatisztikaToolStripMenuItem.Click += new System.EventHandler(this.feladatStatisztikaToolStripMenuItem_Click);
            // 
            // feladatBukkvidektxtToolStripMenuItem
            // 
            this.feladatBukkvidektxtToolStripMenuItem.Name = "feladatBukkvidektxtToolStripMenuItem";
            this.feladatBukkvidektxtToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.feladatBukkvidektxtToolStripMenuItem.Text = "9. feladat - bukk-videk.txt";
            this.feladatBukkvidektxtToolStripMenuItem.Click += new System.EventHandler(this.feladatBukkvidektxtToolStripMenuItem_Click);
            // 
            // kilépésToolStripMenuItem
            // 
            this.kilépésToolStripMenuItem.Name = "kilépésToolStripMenuItem";
            this.kilépésToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.kilépésToolStripMenuItem.Text = "Kilépés";
            this.kilépésToolStripMenuItem.Click += new System.EventHandler(this.kilépésToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(718, 428);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Berdó Tamás";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "1. feladat - Form";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem feladatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kilépésToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feladatToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem feladatSzámolásToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feladatÁtlagToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feladatLegmagasabbToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feladatBörzsönyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feladat3000LábToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feladatStatisztikaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feladatBukkvidektxtToolStripMenuItem;
        private System.Windows.Forms.Label label1;
    }
}

